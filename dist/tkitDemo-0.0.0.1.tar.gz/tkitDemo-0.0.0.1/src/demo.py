# -*- coding: utf-8 -*-

class Demo:
    def __init__(self):
        pass
    def fun(self):
        print("fun run!")
        pass