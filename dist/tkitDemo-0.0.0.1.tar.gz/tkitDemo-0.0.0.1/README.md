# 一个创建库的demo
便于快速创建自己的第三方库

文档查看
https://www.terrychan.org/python_libs_demo/